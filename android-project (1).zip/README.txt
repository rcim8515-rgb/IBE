Upload these files to a GitHub repo. The workflow in .github/workflows/build.yml builds the APK (Actions tab -> Artifacts).
