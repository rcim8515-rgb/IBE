// Iceberg Engine — native C++/SDL2 port (scaffold)
// A real, dependency-light native app that mirrors the original HTML app's
// look (colors/fonts/rounded buttons) and implements one full vertical
// slice end-to-end: Intro -> Main Menu -> Dashboard -> Sprite List ->
// Sprite Editor (draw/save pixel-art sprites). Everything else in the
// original (voxel editor, level editor, song maker, event system, export,
// runtime/player) is not ported yet — see README for the plan to extend.
#include <SDL.h>
#include <SDL_ttf.h>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <cmath>
#include <memory>
#include <fstream>
#include <sstream>

// ----------------------------------------------------------------------
// Colors — pulled straight from styles.css
// ----------------------------------------------------------------------
namespace Col {
    constexpr SDL_Color Black      {0, 0, 0, 255};
    constexpr SDL_Color White      {255, 255, 255, 255};
    constexpr SDL_Color BtnGreenBg {0x4a, 0x8f, 0x3a, 255};
    constexpr SDL_Color BtnGreenFg {0x6d, 0xff, 0x44, 255};
    constexpr SDL_Color BtnBackBg  {0x11, 0x55, 0xcc, 255}; // .btn-back
    constexpr SDL_Color BtnRedBg   {0xcc, 0x22, 0x22, 255}; // .btn-red / exit
    constexpr SDL_Color MMCreateBg {0x8f, 0x8f, 0x95, 255}; // .mm-btn-create
    constexpr SDL_Color MMCreateFg {0x11, 0x11, 0x11, 255};
    constexpr SDL_Color MMLoadBg   {0x0e, 0x10, 0x13, 255}; // .mm-btn-load
    constexpr SDL_Color MMLoadFg   {0xe6, 0xe6, 0xea, 255};
    constexpr SDL_Color MMLoadBorder{0x3a, 0x3a, 0x42, 255};
    constexpr SDL_Color PanelDark  {0x28, 0x28, 0x2d, 255}; // .proj-item
    constexpr SDL_Color TopBorder  {0x22, 0x22, 0x22, 255};
    constexpr SDL_Color Yellow     {0xf0, 0xc0, 0x40, 255}; // .dash-section-lbl
    constexpr SDL_Color Muted      {0xbb, 0xbb, 0xbb, 255};
    constexpr SDL_Color GridLine   {0x3a, 0x3a, 0x42, 255};
}

// ----------------------------------------------------------------------
// Rounded-rect fill (no SDL_gfx dependency)
// ----------------------------------------------------------------------
static void fillCircle(SDL_Renderer* r, int cx, int cy, int rad) {
    for (int dy = -rad; dy <= rad; dy++) {
        int dx = (int)std::round(std::sqrt((double)(rad * rad - dy * dy)));
        SDL_RenderDrawLine(r, cx - dx, cy + dy, cx + dx, cy + dy);
    }
}

static void filledRoundRect(SDL_Renderer* r, SDL_Rect rect, int rad, SDL_Color c) {
    rad = std::min(rad, std::min(rect.w, rect.h) / 2);
    SDL_SetRenderDrawColor(r, c.r, c.g, c.b, c.a);
    SDL_Rect mid{rect.x + rad, rect.y, rect.w - 2 * rad, rect.h};
    SDL_Rect left{rect.x, rect.y + rad, rad, rect.h - 2 * rad};
    SDL_Rect right{rect.x + rect.w - rad, rect.y + rad, rad, rect.h - 2 * rad};
    SDL_RenderFillRect(r, &mid);
    if (rad > 0) {
        SDL_RenderFillRect(r, &left);
        SDL_RenderFillRect(r, &right);
        fillCircle(r, rect.x + rad, rect.y + rad, rad);
        fillCircle(r, rect.x + rect.w - rad, rect.y + rad, rad);
        fillCircle(r, rect.x + rad, rect.y + rect.h - rad, rad);
        fillCircle(r, rect.x + rect.w - rad, rect.y + rect.h - rad, rad);
    }
}

static void strokeRect(SDL_Renderer* r, SDL_Rect rect, SDL_Color c, int w = 1) {
    SDL_SetRenderDrawColor(r, c.r, c.g, c.b, c.a);
    for (int i = 0; i < w; i++) {
        SDL_Rect rr{rect.x + i, rect.y + i, rect.w - 2 * i, rect.h - 2 * i};
        SDL_RenderDrawRect(r, &rr);
    }
}

// ----------------------------------------------------------------------
// Fonts / text — uses the real pixel font extracted from the HTML file
// ----------------------------------------------------------------------
struct FontCache {
    std::map<int, TTF_Font*> fonts;
    std::string path;
    TTF_Font* get(int size) {
        auto it = fonts.find(size);
        if (it != fonts.end()) return it->second;
        TTF_Font* f = TTF_OpenFont(path.c_str(), size);
        fonts[size] = f;
        return f;
    }
} g_fonts;

static std::string toUpper(std::string s) {
    for (auto& c : s) c = (char)toupper((unsigned char)c);
    return s;
}

static void drawText(SDL_Renderer* r, const std::string& text, int size,
                      SDL_Color color, int x, int y, bool center = false) {
    TTF_Font* f = g_fonts.get(size);
    if (!f || text.empty()) return;
    SDL_Surface* surf = TTF_RenderUTF8_Blended(f, text.c_str(), color);
    if (!surf) return;
    SDL_Texture* tex = SDL_CreateTextureFromSurface(r, surf);
    SDL_Rect dst{x, y, surf->w, surf->h};
    if (center) { dst.x -= surf->w / 2; dst.y -= surf->h / 2; }
    SDL_RenderCopy(r, tex, nullptr, &dst);
    SDL_DestroyTexture(tex);
    SDL_FreeSurface(surf);
}

static SDL_Point textSize(const std::string& text, int size) {
    TTF_Font* f = g_fonts.get(size);
    int w = 0, h = 0;
    if (f) TTF_SizeUTF8(f, text.c_str(), &w, &h);
    return {w, h};
}

// ----------------------------------------------------------------------
// Button widget — mirrors .btn / .btn-back / .btn.green / .mm-btn styles
// ----------------------------------------------------------------------
struct Button {
    SDL_Rect rect;
    std::string label;
    SDL_Color bg, fg;
    int radius = 10;
    int fontSize = 16;
    int id = 0; // caller-defined action id

    bool hit(int mx, int my) const {
        return mx >= rect.x && mx < rect.x + rect.w &&
               my >= rect.y && my < rect.y + rect.h;
    }
    void draw(SDL_Renderer* r) const {
        filledRoundRect(r, rect, radius, bg);
        SDL_Point sz = textSize(toUpper(label), fontSize);
        drawText(r, toUpper(label), fontSize, fg,
                  rect.x + rect.w / 2, rect.y + rect.h / 2, true);
        (void)sz;
    }
};

// ----------------------------------------------------------------------
// App state
// ----------------------------------------------------------------------
enum class Screen { Intro, Main, Dashboard, SpriteList, SpriteEditor, ObjectList, ObjectEditor, LevelList, LevelEditor, Play };

struct Sprite {
    std::string name;
    static constexpr int SIZE = 16;
    std::vector<SDL_Color> pixels = std::vector<SDL_Color>(SIZE * SIZE, SDL_Color{0,0,0,0});
};

struct GameObject {
    std::string name;
    int spriteIndex = -1; // index into app.sprites, -1 = none assigned yet
};

struct Level {
    std::string name;
    static constexpr int COLS = 20, ROWS = 12;
    // one object index per tile, -1 = empty
    std::vector<int> tiles = std::vector<int>(COLS * ROWS, -1);
};

// Simple platformer physics for the play-mode runtime. Positions/velocities
// are in "logical" pixels where one tile = kLogicalTile (see updatePlay).
struct PlayState {
    float px = 32, py = 32, vx = 0, vy = 0;
    bool onGround = false;
};

struct AppState {
    Screen screen = Screen::Intro;
    Uint32 introStart = 0;
    std::string gameName = "MY GAME";
    std::vector<Sprite> sprites;
    int editingSprite = -1;
    std::vector<GameObject> objects;
    int editingObject = -1;
    std::vector<Level> levels;
    int editingLevel = -1;
    int currentPlaceObject = -1; // -1 = eraser, in the level editor
    PlayState play;
    SDL_Color currentColor{0x6d, 0xff, 0x44, 255};
    bool mouseDown = false;
    std::string toast;
    Uint32 toastUntil = 0;
} app;

static void showToast(const std::string& msg, Uint32 now) {
    app.toast = msg;
    app.toastUntil = now + 1500;
}

// A small 8-color palette for the sprite editor (kept simple on purpose).
static const std::vector<SDL_Color> kPalette = {
    {255,255,255,255}, {0,0,0,255}, {0xcc,0x22,0x22,255}, {0x4a,0x8f,0x3a,255},
    {0x11,0x55,0xcc,255}, {0xf0,0xc0,0x40,255}, {0x8f,0x8f,0x95,255}, {0,0,0,0} // last = eraser
};

// ----------------------------------------------------------------------
// Disk persistence — one plain-text save file next to the executable.
// Format (pipe-delimited, one record per line, no external deps):
//   GAMENAME|<name>
//   SPRITE|<name>|r,g,b,a;r,g,b,a;...   (256 entries, row-major)
// ----------------------------------------------------------------------
static const char* SAVE_PATH = "iceberg_save.dat";

static std::string colorToStr(SDL_Color c) {
    return std::to_string(c.r) + "," + std::to_string(c.g) + "," +
           std::to_string(c.b) + "," + std::to_string(c.a);
}

static SDL_Color strToColor(const std::string& s) {
    int v[4] = {0, 0, 0, 0};
    std::stringstream ss(s);
    std::string part;
    for (int i = 0; i < 4 && std::getline(ss, part, ','); i++) v[i] = std::stoi(part);
    return SDL_Color{(Uint8)v[0], (Uint8)v[1], (Uint8)v[2], (Uint8)v[3]};
}

static void saveProjectToDisk() {
    std::ofstream f(SAVE_PATH);
    if (!f) return;
    f << "GAMENAME|" << app.gameName << "\n";
    for (auto& s : app.sprites) {
        f << "SPRITE|" << s.name << "|";
        for (size_t i = 0; i < s.pixels.size(); i++) {
            f << colorToStr(s.pixels[i]);
            if (i + 1 < s.pixels.size()) f << ";";
        }
        f << "\n";
    }
    for (auto& o : app.objects) {
        f << "OBJECT|" << o.name << "|" << o.spriteIndex << "\n";
    }
    for (auto& lvl : app.levels) {
        f << "LEVEL|" << lvl.name << "|";
        for (size_t i = 0; i < lvl.tiles.size(); i++) {
            f << lvl.tiles[i];
            if (i + 1 < lvl.tiles.size()) f << ",";
        }
        f << "\n";
    }
}

// Returns true if a save file existed and was loaded.
static bool loadProjectFromDisk() {
    std::ifstream f(SAVE_PATH);
    if (!f) return false;
    app.sprites.clear();
    app.objects.clear();
    app.levels.clear();
    std::string line;
    while (std::getline(f, line)) {
        if (line.empty()) continue;
        size_t p1 = line.find('|');
        if (p1 == std::string::npos) continue;
        std::string tag = line.substr(0, p1);
        if (tag == "GAMENAME") {
            app.gameName = line.substr(p1 + 1);
        } else if (tag == "SPRITE") {
            size_t p2 = line.find('|', p1 + 1);
            if (p2 == std::string::npos) continue;
            Sprite s;
            s.name = line.substr(p1 + 1, p2 - p1 - 1);
            std::string pixelData = line.substr(p2 + 1);
            std::stringstream ss(pixelData);
            std::string entry;
            int idx = 0;
            while (std::getline(ss, entry, ';') && idx < (int)s.pixels.size()) {
                s.pixels[idx++] = strToColor(entry);
            }
            app.sprites.push_back(s);
        } else if (tag == "OBJECT") {
            size_t p2 = line.find('|', p1 + 1);
            if (p2 == std::string::npos) continue;
            GameObject o;
            o.name = line.substr(p1 + 1, p2 - p1 - 1);
            o.spriteIndex = std::stoi(line.substr(p2 + 1));
            app.objects.push_back(o);
        } else if (tag == "LEVEL") {
            size_t p2 = line.find('|', p1 + 1);
            if (p2 == std::string::npos) continue;
            Level lvl;
            lvl.name = line.substr(p1 + 1, p2 - p1 - 1);
            std::string tileData = line.substr(p2 + 1);
            std::stringstream ss(tileData);
            std::string entry;
            int idx = 0;
            while (std::getline(ss, entry, ',') && idx < (int)lvl.tiles.size()) {
                lvl.tiles[idx++] = std::stoi(entry);
            }
            app.levels.push_back(lvl);
        }
    }
    return true;
}

// ----------------------------------------------------------------------
// Screens
// ----------------------------------------------------------------------
static std::vector<Button> buildIntro(int W, int H) {
    (void)W; (void)H;
    return {};
}

static std::vector<Button> buildMain(int W, int H) {
    std::vector<Button> b;
    Button exit{{W - 110, 12, 96, 40}, "EXIT", Col::BtnRedBg, Col::White, 10, 13, 1};
    b.push_back(exit);
    int barW = std::min(580, W - 40);
    int barX = (W - barW) / 2;
    int barY = H / 2 + 20;
    int gap = 14;
    int btnW = (barW - gap) / 2;
    Button create{{barX, barY, btnW, 70}, "CREATE NEW", Col::MMCreateBg, Col::MMCreateFg, 8, 17, 2};
    Button load{{barX + btnW + gap, barY, btnW, 70}, "LOAD GAME", Col::MMLoadBg, Col::MMLoadFg, 8, 17, 3};
    b.push_back(create);
    b.push_back(load);
    return b;
}

static std::vector<Button> buildDashboard(int W, int H) {
    std::vector<Button> b;
    b.push_back({{12, 12, 120, 40}, "< BACK", Col::BtnBackBg, Col::White, 10, 14, 100});
    int y = 100, gap = 14, h = 64;
    int w = std::min(500, W - 40);
    int x = (W - w) / 2;
    const char* labels[] = {"SPRITES", "OBJECTS", "LEVELS", "EXPORT"};
    int ids[] = {10, 11, 12, 13};
    for (int i = 0; i < 4; i++) {
        b.push_back({{x, y, w, h}, labels[i], Col::PanelDark, Col::White, 10, 18, ids[i]});
        y += h + gap;
    }
    (void)H;
    return b;
}

static std::vector<Button> buildSpriteList(int W, int H) {
    std::vector<Button> b;
    b.push_back({{12, 12, 120, 40}, "< BACK", Col::BtnBackBg, Col::White, 10, 14, 100});
    b.push_back({{W - 190, 12, 178, 40}, "+ NEW SPRITE", Col::BtnGreenBg, Col::BtnGreenFg, 10, 14, 20});
    int y = 70, w = std::min(500, W - 40), x = (W - w) / 2, h = 60, gap = 8;
    for (size_t i = 0; i < app.sprites.size(); i++) {
        b.push_back({{x, y, w, h}, app.sprites[i].name, Col::PanelDark, Col::White, 10, 16, 1000 + (int)i});
        y += h + gap;
    }
    (void)H;
    return b;
}

static SDL_Rect gridRect(int W, int H) {
    int cell = std::min((H - 220) / Sprite::SIZE, (W - 60) / Sprite::SIZE);
    cell = std::max(cell, 8);
    int size = cell * Sprite::SIZE;
    return {(W - size) / 2, 90, size, size};
}

static std::vector<Button> buildSpriteEditor(int W, int H) {
    std::vector<Button> b;
    b.push_back({{12, 12, 120, 40}, "< BACK", Col::BtnBackBg, Col::White, 10, 14, 100});
    b.push_back({{W - 130, 12, 118, 40}, "SAVE", Col::BtnGreenBg, Col::BtnGreenFg, 10, 14, 30});
    // palette swatches under the grid
    SDL_Rect grid = gridRect(W, H);
    int sw = 40, sgap = 8;
    int totalW = (int)kPalette.size() * (sw + sgap) - sgap;
    int px = (W - totalW) / 2, py = grid.y + grid.h + 20;
    for (size_t i = 0; i < kPalette.size(); i++) {
        b.push_back({{px + (int)i * (sw + sgap), py, sw, sw}, "", kPalette[i],
                      Col::Black, 6, 10, 2000 + (int)i});
    }
    return b;
}

// Draws a sprite's pixel grid into an arbitrary destination rect (used for
// both the editor's big grid and the small thumbnails below).
static void drawSpriteThumb(SDL_Renderer* r, const Sprite& spr, SDL_Rect dst) {
    int cell = std::max(1, dst.w / Sprite::SIZE);
    for (int y = 0; y < Sprite::SIZE; y++) {
        for (int x = 0; x < Sprite::SIZE; x++) {
            SDL_Rect cr{dst.x + x * cell, dst.y + y * cell, cell, cell};
            bool dark = ((x + y) % 2) == 0;
            SDL_Color bg = dark ? SDL_Color{40,40,44,255} : SDL_Color{55,55,60,255};
            SDL_SetRenderDrawColor(r, bg.r, bg.g, bg.b, 255);
            SDL_RenderFillRect(r, &cr);
            SDL_Color p = spr.pixels[y * Sprite::SIZE + x];
            if (p.a > 0) {
                SDL_SetRenderDrawColor(r, p.r, p.g, p.b, p.a);
                SDL_RenderFillRect(r, &cr);
            }
        }
    }
}

// Draws whatever an object looks like (its assigned sprite, or a plain
// placeholder box if it has none yet) into an arbitrary rect.
static void drawObjectIcon(SDL_Renderer* r, int objectIndex, SDL_Rect dst) {
    if (objectIndex < 0 || objectIndex >= (int)app.objects.size()) return;
    int spriteIdx = app.objects[objectIndex].spriteIndex;
    if (spriteIdx >= 0 && spriteIdx < (int)app.sprites.size()) {
        drawSpriteThumb(r, app.sprites[spriteIdx], dst);
    } else {
        // no sprite assigned yet — give each object a stable placeholder hue
        Uint8 hue = (Uint8)((objectIndex * 63 + 40) % 255);
        filledRoundRect(r, dst, 4, SDL_Color{hue, (Uint8)(200 - hue / 2), 120, 255});
    }
}


static std::vector<Button> buildObjectList(int W, int H) {
    std::vector<Button> b;
    b.push_back({{12, 12, 120, 40}, "< BACK", Col::BtnBackBg, Col::White, 10, 14, 100});
    b.push_back({{W - 190, 12, 178, 40}, "+ NEW OBJECT", Col::BtnGreenBg, Col::BtnGreenFg, 10, 14, 40});
    int y = 70, w = std::min(500, W - 40), x = (W - w) / 2, h = 64, gap = 8;
    for (size_t i = 0; i < app.objects.size(); i++) {
        std::string label = app.objects[i].name;
        b.push_back({{x, y, w, h}, label, Col::PanelDark, Col::White, 10, 16, 3000 + (int)i});
        y += h + gap;
    }
    (void)H;
    return b;
}

static std::vector<Button> buildObjectEditor(int W, int H) {
    std::vector<Button> b;
    b.push_back({{12, 12, 120, 40}, "< BACK", Col::BtnBackBg, Col::White, 10, 14, 100});
    b.push_back({{W - 130, 12, 118, 40}, "SAVE", Col::BtnGreenBg, Col::BtnGreenFg, 10, 14, 50});
    // sprite picker grid below the big preview
    int previewSize = std::min(160, H / 3);
    int gridTop = 90 + previewSize + 30;
    int cell = 70, gap = 10;
    int perRow = std::max(1, (W - 40) / (cell + gap));
    int startX = (W - std::min((int)app.sprites.size(), perRow) * (cell + gap) + gap) / 2;
    for (size_t i = 0; i < app.sprites.size(); i++) {
        int col = (int)i % perRow, row = (int)i / perRow;
        int bx = startX + col * (cell + gap);
        int by = gridTop + row * (cell + gap);
        b.push_back({{bx, by, cell, cell}, "", Col::PanelDark, Col::White, 6, 10, 4000 + (int)i});
    }
    (void)H;
    return b;
}

static std::vector<Button> buildLevelList(int W, int H) {
    std::vector<Button> b;
    b.push_back({{12, 12, 120, 40}, "< BACK", Col::BtnBackBg, Col::White, 10, 14, 100});
    b.push_back({{W - 180, 12, 168, 40}, "+ NEW LEVEL", Col::BtnGreenBg, Col::BtnGreenFg, 10, 14, 60});
    int y = 70, w = std::min(500, W - 40), x = (W - w) / 2, h = 64, gap = 8;
    for (size_t i = 0; i < app.levels.size(); i++) {
        b.push_back({{x, y, w, h}, app.levels[i].name, Col::PanelDark, Col::White, 10, 16, 6000 + (int)i});
        y += h + gap;
    }
    (void)H;
    return b;
}

// Reserves top space for the topbar and bottom space for the object palette
// strip, and fits the level's tile grid into whatever remains.
static SDL_Rect levelGridRect(int W, int H) {
    int availH = H - 90 - 130;
    int cellW = (W - 40) / Level::COLS;
    int cellH = std::max(availH, 40) / Level::ROWS;
    int cell = std::max(std::min(cellW, cellH), 6);
    int w = cell * Level::COLS, h = cell * Level::ROWS;
    return {(W - w) / 2, 90, w, h};
}

static std::vector<Button> buildLevelEditor(int W, int H) {
    std::vector<Button> b;
    b.push_back({{12, 12, 120, 40}, "< BACK", Col::BtnBackBg, Col::White, 10, 14, 100});
    b.push_back({{W / 2 - 65, 12, 130, 40}, "PLAY ▶", Col::White, Col::Black, 10, 14, 80});
    b.push_back({{W - 130, 12, 118, 40}, "SAVE", Col::BtnGreenBg, Col::BtnGreenFg, 10, 14, 70});
    SDL_Rect grid = levelGridRect(W, H);
    // object palette strip below the grid: one swatch per object + an eraser
    int sw = 48, sgap = 8;
    int count = (int)app.objects.size() + 1; // +1 for eraser
    int totalW = count * (sw + sgap) - sgap;
    int px = std::max(10, (W - totalW) / 2);
    int py = grid.y + grid.h + 16;
    for (size_t i = 0; i < app.objects.size(); i++) {
        b.push_back({{px + (int)i * (sw + sgap), py, sw, sw}, "", Col::PanelDark, Col::White, 6, 10, 7000 + (int)i});
    }
    b.push_back({{px + (int)app.objects.size() * (sw + sgap), py, sw, sw}, "X", Col::BtnRedBg, Col::White, 6, 14, 7999});
    return b;
}

static std::vector<Button> buildPlay(int W, int H) {
    (void)W; (void)H;
    std::vector<Button> b;
    b.push_back({{12, 12, 130, 40}, "■ STOP", Col::BtnRedBg, Col::White, 10, 14, 100});
    return b;
}

// ----------------------------------------------------------------------
// Play-mode runtime — a minimal real platformer: gravity, left/right,
// jump, and collision against every placed object (all treated as solid
// for now — there's no object "type" property yet to mark decorations).
// ----------------------------------------------------------------------
static constexpr float kLogicalTile = 32.0f;
static constexpr float kGravity = 1400.0f;
static constexpr float kMoveSpeed = 220.0f;
static constexpr float kJumpSpeed = 480.0f;
static constexpr float kMaxFall = 900.0f;

static bool tileSolid(const Level& lvl, int tx, int ty) {
    if (tx < 0 || ty < 0 || tx >= Level::COLS || ty >= Level::ROWS) return false;
    return lvl.tiles[ty * Level::COLS + tx] != -1;
}

static void resetPlay() {
    app.play = PlayState{};
    app.play.px = kLogicalTile;
    app.play.py = kLogicalTile;
}

static void updatePlay(float dt, const Uint8* keys) {
    if (app.editingLevel < 0) return;
    auto& lvl = app.levels[app.editingLevel];
    auto& p = app.play;

    p.vx = 0;
    if (keys[SDL_SCANCODE_LEFT] || keys[SDL_SCANCODE_A]) p.vx -= kMoveSpeed;
    if (keys[SDL_SCANCODE_RIGHT] || keys[SDL_SCANCODE_D]) p.vx += kMoveSpeed;
    p.vy += kGravity * dt;
    if (p.vy > kMaxFall) p.vy = kMaxFall;

    // Horizontal move + collision
    float newX = p.px + p.vx * dt;
    int ty0 = (int)(p.py / kLogicalTile);
    int ty1 = (int)((p.py + kLogicalTile - 1) / kLogicalTile);
    if (p.vx > 0) {
        int tx = (int)((newX + kLogicalTile - 1) / kLogicalTile);
        for (int ty = ty0; ty <= ty1; ty++)
            if (tileSolid(lvl, tx, ty)) { newX = tx * kLogicalTile - kLogicalTile; break; }
    } else if (p.vx < 0) {
        int tx = (int)(newX / kLogicalTile);
        for (int ty = ty0; ty <= ty1; ty++)
            if (tileSolid(lvl, tx, ty)) { newX = (tx + 1) * kLogicalTile; break; }
    }
    p.px = newX;

    // Vertical move + collision
    float newY = p.py + p.vy * dt;
    int tx0 = (int)(p.px / kLogicalTile);
    int tx1 = (int)((p.px + kLogicalTile - 1) / kLogicalTile);
    p.onGround = false;
    if (p.vy > 0) {
        int ty = (int)((newY + kLogicalTile - 1) / kLogicalTile);
        for (int tx = tx0; tx <= tx1; tx++)
            if (tileSolid(lvl, tx, ty)) { newY = ty * kLogicalTile - kLogicalTile; p.vy = 0; p.onGround = true; break; }
    } else if (p.vy < 0) {
        int ty = (int)(newY / kLogicalTile);
        for (int tx = tx0; tx <= tx1; tx++)
            if (tileSolid(lvl, tx, ty)) { newY = (ty + 1) * kLogicalTile; p.vy = 0; break; }
    }
    p.py = newY;

    // Fell off the level -> respawn
    if (p.py > Level::ROWS * kLogicalTile + 200) resetPlay();
}

// Maps the logical (32px/tile) level space onto whatever screen area is
// available, uniformly scaled so the whole level is always visible.
static void computePlayLayout(int W, int H, float& scale, int& originX, int& originY) {
    float levelW = Level::COLS * kLogicalTile, levelH = Level::ROWS * kLogicalTile;
    float availW = (float)(W - 40), availH = (float)(H - 140);
    scale = std::max(0.1f, std::min(availW / levelW, availH / levelH));
    originX = (int)((W - levelW * scale) / 2);
    originY = 90;
}




// ----------------------------------------------------------------------
// Rendering helpers
// ----------------------------------------------------------------------
static void clear(SDL_Renderer* r) {
    SDL_SetRenderDrawColor(r, 0, 0, 0, 255);
    SDL_RenderClear(r);
}

static void drawTopBorder(SDL_Renderer* r, int W, int y = 64) {
    strokeRect(r, {0, y - 2, W, 2}, Col::TopBorder);
}

static void drawToast(SDL_Renderer* r, int W, int H, Uint32 now) {
    if (app.toast.empty() || now > app.toastUntil) return;
    SDL_Point sz = textSize(app.toast, 14);
    SDL_Rect box{W / 2 - sz.x / 2 - 16, H - 70, sz.x + 32, 36};
    filledRoundRect(r, box, 10, {40, 40, 44, 230});
    drawText(r, app.toast, 14, Col::White, W / 2, H - 52, true);
}

int main(int argc, char** argv) {
    (void)argc; (void)argv;
    SDL_Init(SDL_INIT_VIDEO);
    TTF_Init();
    g_fonts.path = "assets/LowerPixel.otf";

    int W = 960, H = 640;
    SDL_Window* win = SDL_CreateWindow("Iceberg Engine", SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED, W, H, SDL_WINDOW_RESIZABLE);
    SDL_Renderer* ren = SDL_CreateRenderer(win, -1,
        SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_BLEND);

    app.introStart = SDL_GetTicks();
    bool running = true;
    bool painting = false;
    Uint32 lastTicks = SDL_GetTicks();

    while (running) {
        Uint32 now = SDL_GetTicks();
        SDL_GetWindowSize(win, &W, &H);

        std::vector<Button> buttons;
        switch (app.screen) {
            case Screen::Intro:        buttons = buildIntro(W, H); break;
            case Screen::Main:         buttons = buildMain(W, H); break;
            case Screen::Dashboard:    buttons = buildDashboard(W, H); break;
            case Screen::SpriteList:   buttons = buildSpriteList(W, H); break;
            case Screen::SpriteEditor: buttons = buildSpriteEditor(W, H); break;
            case Screen::ObjectList:   buttons = buildObjectList(W, H); break;
            case Screen::ObjectEditor: buttons = buildObjectEditor(W, H); break;
            case Screen::LevelList:    buttons = buildLevelList(W, H); break;
            case Screen::LevelEditor:  buttons = buildLevelEditor(W, H); break;
            case Screen::Play:         buttons = buildPlay(W, H); break;
        }

        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) running = false;
            if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE) {
                if (app.screen == Screen::Play) app.screen = Screen::LevelEditor;
                else running = false;
            }
            if (!running && app.screen != Screen::Intro && app.screen != Screen::Main)
                saveProjectToDisk();

            if (app.screen == Screen::Intro &&
                (e.type == SDL_MOUSEBUTTONDOWN || e.type == SDL_KEYDOWN)) {
                app.screen = Screen::Main;
            }

            if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT) {
                int mx = e.button.x, my = e.button.y;
                for (auto& btn : buttons) {
                    if (!btn.hit(mx, my)) continue;
                    int id = btn.id;
                    if (id == 1) running = false;                       // exit
                    else if (id == 2) {                                  // create new
                        app.sprites.clear();
                        app.gameName = "NEW GAME";
                        app.screen = Screen::Dashboard;
                        saveProjectToDisk();
                    } else if (id == 3) {                                 // load
                        if (loadProjectFromDisk()) {
                            app.screen = Screen::Dashboard;
                        } else {
                            showToast("No saved game found", now);
                        }
                    } else if (id == 100) {                                // back
                        if (app.screen == Screen::Dashboard) app.screen = Screen::Main;
                        else if (app.screen == Screen::SpriteList) app.screen = Screen::Dashboard;
                        else if (app.screen == Screen::SpriteEditor) {
                            app.screen = Screen::SpriteList;
                            saveProjectToDisk(); // don't lose unsaved edits
                        } else if (app.screen == Screen::ObjectList) {
                            app.screen = Screen::Dashboard;
                        } else if (app.screen == Screen::ObjectEditor) {
                            app.screen = Screen::ObjectList;
                            saveProjectToDisk();
                        } else if (app.screen == Screen::LevelList) {
                            app.screen = Screen::Dashboard;
                        } else if (app.screen == Screen::LevelEditor) {
                            app.screen = Screen::LevelList;
                            saveProjectToDisk();
                        } else if (app.screen == Screen::Play) {
                            app.screen = Screen::LevelEditor;
                        }
                    } else if (id == 10) app.screen = Screen::SpriteList;  // sprites
                    else if (id == 11) app.screen = Screen::ObjectList;     // objects
                    else if (id == 12) app.screen = Screen::LevelList;      // levels
                    else if (id == 13) showToast("Not implemented yet", now); // export
                    else if (id == 20) {                                   // new sprite
                        Sprite s; s.name = "SPRITE " + std::to_string(app.sprites.size() + 1);
                        app.sprites.push_back(s);
                        app.editingSprite = (int)app.sprites.size() - 1;
                        app.screen = Screen::SpriteEditor;
                        saveProjectToDisk();
                    } else if (id >= 1000 && id < 2000) {                   // open sprite
                        app.editingSprite = id - 1000;
                        app.screen = Screen::SpriteEditor;
                    } else if (id == 30) {                                  // save sprite
                        saveProjectToDisk();
                        showToast("Sprite saved to disk", now);
                        app.screen = Screen::SpriteList;
                    } else if (id >= 2000 && id < 3000) {                   // palette pick
                        app.currentColor = kPalette[id - 2000];
                    } else if (id == 40) {                                  // new object
                        GameObject o; o.name = "OBJECT " + std::to_string(app.objects.size() + 1);
                        app.objects.push_back(o);
                        app.editingObject = (int)app.objects.size() - 1;
                        app.screen = Screen::ObjectEditor;
                        saveProjectToDisk();
                    } else if (id >= 3000 && id < 4000) {                   // open object
                        app.editingObject = id - 3000;
                        app.screen = Screen::ObjectEditor;
                    } else if (id == 50) {                                  // save object
                        saveProjectToDisk();
                        showToast("Object saved to disk", now);
                        app.screen = Screen::ObjectList;
                    } else if (id >= 4000 && id < 5000) {                   // assign sprite to object
                        if (app.editingObject >= 0) app.objects[app.editingObject].spriteIndex = id - 4000;
                    } else if (id == 60) {                                  // new level
                        Level lvl; lvl.name = "LEVEL " + std::to_string(app.levels.size() + 1);
                        app.levels.push_back(lvl);
                        app.editingLevel = (int)app.levels.size() - 1;
                        app.currentPlaceObject = -1;
                        app.screen = Screen::LevelEditor;
                        saveProjectToDisk();
                    } else if (id >= 6000 && id < 7000) {                   // open level
                        app.editingLevel = id - 6000;
                        app.currentPlaceObject = -1;
                        app.screen = Screen::LevelEditor;
                    } else if (id == 70) {                                  // save level
                        saveProjectToDisk();
                        showToast("Level saved to disk", now);
                        app.screen = Screen::LevelList;
                    } else if (id >= 7000 && id < 7999) {                   // pick object to place
                        app.currentPlaceObject = id - 7000;
                    } else if (id == 7999) {                                // eraser
                        app.currentPlaceObject = -1;
                    } else if (id == 80) {                                  // enter play mode
                        resetPlay();
                        app.screen = Screen::Play;
                    }
                }
                if (app.screen == Screen::SpriteEditor || app.screen == Screen::LevelEditor) painting = true;
            }
            if (e.type == SDL_MOUSEBUTTONUP) painting = false;

            if ((e.type == SDL_MOUSEBUTTONDOWN || e.type == SDL_MOUSEMOTION) &&
                app.screen == Screen::SpriteEditor && painting && app.editingSprite >= 0) {
                int mx, my; SDL_GetMouseState(&mx, &my);
                SDL_Rect grid = gridRect(W, H);
                if (mx >= grid.x && mx < grid.x + grid.w && my >= grid.y && my < grid.y + grid.h) {
                    int cell = grid.w / Sprite::SIZE;
                    int gx = (mx - grid.x) / cell, gy = (my - grid.y) / cell;
                    auto& spr = app.sprites[app.editingSprite];
                    spr.pixels[gy * Sprite::SIZE + gx] = app.currentColor;
                }
            }

            if ((e.type == SDL_MOUSEBUTTONDOWN || e.type == SDL_MOUSEMOTION) &&
                app.screen == Screen::LevelEditor && painting && app.editingLevel >= 0) {
                int mx, my; SDL_GetMouseState(&mx, &my);
                SDL_Rect grid = levelGridRect(W, H);
                if (mx >= grid.x && mx < grid.x + grid.w && my >= grid.y && my < grid.y + grid.h) {
                    int cell = grid.w / Level::COLS;
                    int gx = (mx - grid.x) / cell, gy = (my - grid.y) / cell;
                    auto& lvl = app.levels[app.editingLevel];
                    lvl.tiles[gy * Level::COLS + gx] = app.currentPlaceObject;
                }
            }

            if (app.screen == Screen::Play && e.type == SDL_KEYDOWN && e.key.repeat == 0 &&
                (e.key.keysym.sym == SDLK_SPACE || e.key.keysym.sym == SDLK_UP || e.key.keysym.sym == SDLK_w) &&
                app.play.onGround) {
                app.play.vy = -kJumpSpeed;
                app.play.onGround = false;
            }
        }

        if (app.screen == Screen::Play) {
            float dt = std::min(0.033f, (now - lastTicks) / 1000.0f);
            updatePlay(dt, SDL_GetKeyboardState(nullptr));
        }
        lastTicks = now;

        // ---------------- draw ----------------
        clear(ren);
        if (app.screen == Screen::Intro) {
            if (now - app.introStart > 2000) app.screen = Screen::Main;
            drawText(ren, "ICEBERG ENGINE", 44, Col::White, W / 2, H / 2 - 20, true);
            drawText(ren, "click to continue", 14, Col::Muted, W / 2, H / 2 + 30, true);
        } else if (app.screen == Screen::Main) {
            drawText(ren, "ICEBERG ENGINE", 32, Col::White, W / 2, H / 2 - 120, true);
            drawText(ren, "v1.0 native", 12, Col::Muted, W - 90, H - 24, true);
        } else if (app.screen == Screen::Dashboard) {
            drawTopBorder(ren, W);
            drawText(ren, app.gameName, 20, Col::White, W / 2, 32, true);
        } else if (app.screen == Screen::SpriteList) {
            drawTopBorder(ren, W);
            drawText(ren, "SPRITES", 20, Col::White, W / 2, 32, true);
            if (app.sprites.empty())
                drawText(ren, "no sprites yet", 14, Col::Muted, W / 2, 90, true);
        } else if (app.screen == Screen::SpriteEditor && app.editingSprite >= 0) {
            drawTopBorder(ren, W);
            drawText(ren, app.sprites[app.editingSprite].name, 18, Col::White, W / 2, 32, true);
            SDL_Rect grid = gridRect(W, H);
            drawSpriteThumb(ren, app.sprites[app.editingSprite], grid);
            strokeRect(ren, grid, Col::GridLine, 2);
        } else if (app.screen == Screen::ObjectList) {
            drawTopBorder(ren, W);
            drawText(ren, "OBJECTS", 20, Col::White, W / 2, 32, true);
            if (app.objects.empty())
                drawText(ren, "no objects yet", 14, Col::Muted, W / 2, 90, true);
        } else if (app.screen == Screen::ObjectEditor && app.editingObject >= 0) {
            drawTopBorder(ren, W);
            auto& obj = app.objects[app.editingObject];
            drawText(ren, obj.name, 18, Col::White, W / 2, 32, true);
            int previewSize = std::min(160, H / 3);
            SDL_Rect preview{W / 2 - previewSize / 2, 90, previewSize, previewSize};
            if (obj.spriteIndex >= 0 && obj.spriteIndex < (int)app.sprites.size()) {
                drawSpriteThumb(ren, app.sprites[obj.spriteIndex], preview);
            } else {
                filledRoundRect(ren, preview, 8, {30, 30, 34, 255});
                drawText(ren, "no sprite", 12, Col::Muted, preview.x + preview.w / 2,
                          preview.y + preview.h / 2, true);
            }
            strokeRect(ren, preview, Col::GridLine, 2);
            drawText(ren, "pick a sprite:", 13, Col::Muted, W / 2, 90 + previewSize + 14, true);
            if (app.sprites.empty())
                drawText(ren, "create a sprite first", 13, Col::Muted, W / 2, 90 + previewSize + 40, true);
        } else if (app.screen == Screen::LevelList) {
            drawTopBorder(ren, W);
            drawText(ren, "LEVELS", 20, Col::White, W / 2, 32, true);
            if (app.levels.empty())
                drawText(ren, "no levels yet", 14, Col::Muted, W / 2, 90, true);
        } else if (app.screen == Screen::LevelEditor && app.editingLevel >= 0) {
            drawTopBorder(ren, W);
            auto& lvl = app.levels[app.editingLevel];
            drawText(ren, lvl.name, 18, Col::White, W / 2, 32, true);
            SDL_Rect grid = levelGridRect(W, H);
            int cell = grid.w / Level::COLS;
            for (int y = 0; y < Level::ROWS; y++) {
                for (int x = 0; x < Level::COLS; x++) {
                    SDL_Rect cr{grid.x + x * cell, grid.y + y * cell, cell, cell};
                    bool dark = ((x + y) % 2) == 0;
                    SDL_Color bg = dark ? SDL_Color{22,22,26,255} : SDL_Color{30,30,34,255};
                    SDL_SetRenderDrawColor(ren, bg.r, bg.g, bg.b, 255);
                    SDL_RenderFillRect(ren, &cr);
                    int objIdx = lvl.tiles[y * Level::COLS + x];
                    if (objIdx >= 0) drawObjectIcon(ren, objIdx, cr);
                }
            }
            strokeRect(ren, grid, Col::GridLine, 2);
            if (app.objects.empty())
                drawText(ren, "create an object first", 12, Col::Muted, W / 2, grid.y + grid.h + 40, true);
        } else if (app.screen == Screen::Play && app.editingLevel >= 0) {
            auto& lvl = app.levels[app.editingLevel];
            float scale; int originX, originY;
            computePlayLayout(W, H, scale, originX, originY);
            int cell = std::max(1, (int)std::round(kLogicalTile * scale));
            for (int y = 0; y < Level::ROWS; y++) {
                for (int x = 0; x < Level::COLS; x++) {
                    int objIdx = lvl.tiles[y * Level::COLS + x];
                    if (objIdx < 0) continue;
                    SDL_Rect cr{originX + x * cell, originY + y * cell, cell, cell};
                    drawObjectIcon(ren, objIdx, cr);
                }
            }
            SDL_Rect prect{originX + (int)std::round(app.play.px * scale),
                            originY + (int)std::round(app.play.py * scale), cell, cell};
            filledRoundRect(ren, prect, 4, {0x6d, 0xff, 0x44, 255});
            strokeRect(ren, prect, Col::Black, 2);
            drawText(ren, lvl.name + " — PLAY MODE", 16, Col::White, W / 2, 32, true);
            drawText(ren, "arrows/wasd move, space jump", 12, Col::Muted, W / 2, H - 20, true);
        }

        for (auto& btn : buttons) btn.draw(ren);
        if (app.screen == Screen::ObjectEditor && app.editingObject >= 0) {
            auto& obj = app.objects[app.editingObject];
            for (auto& btn : buttons) {
                if (btn.id < 4000 || btn.id >= 5000) continue;
                int spriteIdx = btn.id - 4000;
                drawSpriteThumb(ren, app.sprites[spriteIdx], btn.rect);
                if (spriteIdx == obj.spriteIndex)
                    strokeRect(ren, btn.rect, Col::BtnGreenFg, 3);
                else
                    strokeRect(ren, btn.rect, Col::GridLine, 1);
            }
        }
        if (app.screen == Screen::LevelEditor) {
            for (auto& btn : buttons) {
                bool isObjSwatch = btn.id >= 7000 && btn.id < 7999;
                bool isEraser = btn.id == 7999;
                if (!isObjSwatch && !isEraser) continue;
                int objIdx = isObjSwatch ? btn.id - 7000 : -1;
                if (isObjSwatch) drawObjectIcon(ren, objIdx, btn.rect);
                bool selected = (isObjSwatch && objIdx == app.currentPlaceObject) ||
                                 (isEraser && app.currentPlaceObject == -1);
                strokeRect(ren, btn.rect, selected ? Col::BtnGreenFg : Col::GridLine, selected ? 3 : 1);
            }
        }
        drawToast(ren, W, H, now);
        SDL_RenderPresent(ren);
        SDL_Delay(8);
    }

    TTF_Quit();
    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(win);
    SDL_Quit();
    return 0;
}
