#include <android_native_app_glue.h>
#include <android/log.h>
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>

#ifndef USER_HAS_ANDROID_MAIN
extern int user_main() __attribute__((weak));
extern int user_main(int, char**) __attribute__((weak));

static void* pump(void* a) {
    int fd = *(int*)a; char buf[512]; ssize_t n;
    while ((n = read(fd, buf, sizeof(buf) - 1)) > 0) {
        buf[n] = 0;
        __android_log_write(ANDROID_LOG_INFO, "cpp2apk", buf);
    }
    return nullptr;
}

static void* run_user(void*) {
    static char arg0[] = "app";
    char* argv[] = {arg0, nullptr};
    int rc = 0;
    if ((void*)(int (*)(int, char**))user_main) rc = user_main(1, argv);
    else rc = user_main();
    fflush(stdout);
    __android_log_print(ANDROID_LOG_INFO, "cpp2apk", "main() returned %d", rc);
    return nullptr;
}

void android_main(struct android_app* app) {
    static int fds[2];
    if (pipe(fds) == 0) {
        dup2(fds[1], 1); dup2(fds[1], 2);
        setvbuf(stdout, nullptr, _IONBF, 0);
        pthread_t t; pthread_create(&t, nullptr, pump, &fds[0]); pthread_detach(t);
    }
    pthread_t u; pthread_create(&u, nullptr, run_user, nullptr); pthread_detach(u);
    while (true) {
        int ev; struct android_poll_source* src;
        while (ALooper_pollAll(-1, nullptr, &ev, (void**)&src) >= 0) {
            if (src) src->process(app, src);
            if (app->destroyRequested) return;
        }
    }
}
#endif
